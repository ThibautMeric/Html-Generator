
def RefreshBV(lfBootVersion):
    lfBootVersion.children["versionchoice"].pack(padx=40,pady=5)
    lfBootVersion.grid(row=1, column=1, sticky= "n e w")
pass
