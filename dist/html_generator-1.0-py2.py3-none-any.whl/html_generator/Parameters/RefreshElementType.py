
def RefreshET(lfBoxType):
    lfBoxType.children["elementchoice"].pack(padx=40,pady=5)
    lfBoxType.grid(row=2, column=1, sticky= "n e w")
pass
