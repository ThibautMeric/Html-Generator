def RefreshOP(lfOutpout):
    lfOutpout.children["outputwindow"].pack()
    lfOutpout.grid(row=1, column=2,rowspan=100)
pass