You can create Panel, Well, Thumbails, Cards, header, footer, paragraph, images define size padding etc


